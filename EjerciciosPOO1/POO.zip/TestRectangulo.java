package poo;

public class TestRectangulo {

         // Método principal para probar la clase
    public static void main(String[] args) {
        Rectangulo miRectangulo = new Rectangulo(5.0, 3.0);
        System.out.println(miRectangulo.toString());
    }
}
